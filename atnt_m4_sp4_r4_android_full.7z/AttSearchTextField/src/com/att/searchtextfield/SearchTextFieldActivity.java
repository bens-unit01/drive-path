package com.att.searchtextfield;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.att.widgets.lib.edittext.SearchTextField;

public class SearchTextFieldActivity extends Activity implements View.OnClickListener{
   
	private SearchTextField search;
	private SearchTextField disabledSearch;
	private SearchTextField unfocusedSearch;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        search = (SearchTextField) findViewById(R.id.searchTextField);
        disabledSearch = (SearchTextField) findViewById(R.id.searchTextField_2);
        unfocusedSearch = (SearchTextField) findViewById(R.id.searchTextField_3);
        disabledSearch.setEnabled(false);
        unfocusedSearch.setFocusable(false);
        search.setOnClickListener(this);
    }


	public void onClick(View v) {
		search.setText("");
		Toast.makeText(this, "Searching content...", Toast.LENGTH_SHORT).show();
	}


}