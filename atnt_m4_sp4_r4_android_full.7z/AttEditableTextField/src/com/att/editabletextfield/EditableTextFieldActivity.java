package com.att.editabletextfield;


import android.app.Activity;
import android.os.Bundle;

import com.att.widgets.lib.edittext.EditableTextField;

public class EditableTextFieldActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);
        
        EditableTextField editableTextField_1 = (EditableTextField) findViewById(R.id.editableTextField_1);
        editableTextField_1.setLabelText("Hello!");
        editableTextField_1.setText("This is an example to demostrate how the Label Edit Text works.");
        
        EditableTextField editableTextField_2 = (EditableTextField) findViewById(R.id.editableTextField_2);
        editableTextField_2.setLabelText("Hello!");
        editableTextField_2.setText("This is an example to demostrate how the Label Edit Text works in disable mode.");
        editableTextField_2.setEnabled(false);
        
        EditableTextField editableTextField_3 = (EditableTextField) findViewById(R.id.editableTextField_3);
        editableTextField_3.setLabelText("Hello!");
        editableTextField_3.setText("This is an example to demostrate how the Label Edit Text works in disable and not focusable mode.");
        editableTextField_3.setEnabled(false);
        editableTextField_3.setFocusable(false);
    }
}