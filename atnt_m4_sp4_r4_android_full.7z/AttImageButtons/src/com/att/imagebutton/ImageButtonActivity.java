package com.att.imagebutton;

import android.app.Activity;
import android.os.Bundle;

import com.att.widgets.lib.button.ImageButton;

public class ImageButtonActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Disabling image button is only allowed by code
        setContentView(R.layout.main);
        ((ImageButton) this.findViewById(R.id.btn1_disabled)).setEnabled(false);
        ((ImageButton) this.findViewById(R.id.btn2_disabled)).setEnabled(false);
        ((ImageButton) this.findViewById(R.id.btn3_disabled)).setEnabled(false);
        ((ImageButton) this.findViewById(R.id.btn4_disabled)).setEnabled(false);
        ((ImageButton) this.findViewById(R.id.btn5_disabled)).setEnabled(false);
        ((ImageButton) this.findViewById(R.id.btn6_disabled)).setEnabled(false);
        ((ImageButton) this.findViewById(R.id.btn7_disabled)).setEnabled(false);
    }
}