package com.att.segmentedtexttogglebutton;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.att.widgets.lib.button.ImageToggleButton;
import com.att.widgets.lib.button.SegmentedTextToggleButton;

public class SegmentedTextToggleButtonActivity extends Activity implements OnClickListener{
    
	private TextView toggleText;
	private SegmentedTextToggleButton toggleButton;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
		ViewGroup v = (ViewGroup)findViewById(R.id.segmented_togglebutton_main);
		SegmentedTextToggleButton segmentedToggle = new SegmentedTextToggleButton(this);
		ImageToggleButton imageToggleButton = new ImageToggleButton(this);
		imageToggleButton.setText("Toggle 1");
		segmentedToggle.addButton(imageToggleButton);
		imageToggleButton = new ImageToggleButton(this);
		imageToggleButton.setText("Toggle 2");
		segmentedToggle.addButton(imageToggleButton);
		segmentedToggle.init();
		v.addView(segmentedToggle);
		
		toggleButton = (SegmentedTextToggleButton)findViewById(R.id.segmented_enabled);
		toggleButton.setOnClickListener(this);
		toggleText = (TextView)findViewById(R.id.segmented_enabled_text);
		
		SegmentedTextToggleButton segmentedTextToggleButtonDisable = (SegmentedTextToggleButton)findViewById(R.id.segmented_disabled);
		segmentedTextToggleButtonDisable.setEnabled(false);
		segmentedTextToggleButtonDisable.setSelectedIndex(2);
		
    }

	public void onClick(View v) {
		toggleText.setText("Selected toggle index= " + toggleButton.getSelectedIndex());
		
	}
}