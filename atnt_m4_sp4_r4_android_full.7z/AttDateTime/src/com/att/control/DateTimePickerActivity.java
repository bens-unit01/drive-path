package com.att.control;


import java.util.Calendar;

import android.app.Activity;
import android.os.Bundle;

import com.att.widgets.lib.datetime.DatePicker;
import com.att.widgets.lib.datetime.TimePicker;

public class DateTimePickerActivity extends Activity {
	private Calendar myCalendar;
	private DatePicker datePicker;
	private TimePicker timePicker;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        datePicker = (DatePicker) findViewById(R.id.date_picker);
        timePicker = (TimePicker) findViewById(R.id.time_picker);
        
        //Custom Start and End Year of DatePicker, if you don't default values are 1900 to 2100
        datePicker.setStartAndEndYear(1990, 2020);
        
        //Set custom date  7=august , day 5 , 1992 , if you don't get the System Date
        myCalendar=Calendar.getInstance();
        myCalendar.set(1992, 7, 5);
        
        datePicker.setCalendar(myCalendar);
        
    }
	
}
