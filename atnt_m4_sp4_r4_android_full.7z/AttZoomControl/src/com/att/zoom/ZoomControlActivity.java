package com.att.zoom;

import android.app.Activity;
import android.os.Bundle;

import com.att.widgets.lib.zoom.ZoomControl;

public class ZoomControlActivity extends Activity {
    private ZoomControl zoomControl;

	/** Called when the activity is first created. */
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
		zoomControl = (ZoomControl)findViewById(R.id.zoom_control);
		zoomControl.setImage(R.drawable.attlogo);
		zoomControl.setMaxZoom(10);
    }
}