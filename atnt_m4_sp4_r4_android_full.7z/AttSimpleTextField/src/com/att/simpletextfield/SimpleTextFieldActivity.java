package com.att.simpletextfield;

import android.app.Activity;
import android.os.Bundle;

import com.att.widgets.lib.edittext.SimpleTextField;

public class SimpleTextFieldActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        SimpleTextField simple = (SimpleTextField) findViewById(R.id.simpleTextField);
    	SimpleTextField disabledSimple = (SimpleTextField) findViewById(R.id.simpleTextField_2);
		SimpleTextField unfocusableSimple = (SimpleTextField) findViewById(R.id.simpleTextField_3);
		disabledSimple.setEnabled(false);
		unfocusableSimple.setFocusable(false);
    }
}