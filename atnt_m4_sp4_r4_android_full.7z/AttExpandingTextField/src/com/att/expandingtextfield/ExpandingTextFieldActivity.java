package com.att.expandingtextfield;

import com.att.widgets.lib.edittext.ExpandingTextField;

import android.app.Activity;
import android.os.Bundle;

public class ExpandingTextFieldActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ((ExpandingTextField)findViewById(R.id.expandingTextField_2)).setEnabled(false);
        ((ExpandingTextField)findViewById(R.id.expandingTextField_3)).setEnabled(false);
        ((ExpandingTextField)findViewById(R.id.expandingTextField_3)).setFocusable(false);
    }
}