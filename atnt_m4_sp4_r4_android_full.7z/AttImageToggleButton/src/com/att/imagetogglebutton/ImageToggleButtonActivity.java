package com.att.imagetogglebutton;

import android.app.Activity;
import android.os.Bundle;

import com.att.widgets.lib.button.ImageToggleButton;

public class ImageToggleButtonActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
		ImageToggleButton toggleButtonEnable = (ImageToggleButton)findViewById(R.id.togglebutton_enable);
		toggleButtonEnable.setFocusable(true);
		
		ImageToggleButton toggleButtonDisableUnpress = (ImageToggleButton)findViewById(R.id.togglebutton_disable_unpress);
		toggleButtonDisableUnpress.setEnabled(false);
		
		ImageToggleButton toggleButtonDisablePress = (ImageToggleButton)findViewById(R.id.togglebutton_disable_press);
		toggleButtonDisablePress.setEnabled(false);
		toggleButtonDisablePress.setChecked(true);
    }
}