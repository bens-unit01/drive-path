package com.att.dropdown;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.att.widgets.lib.dropdown.DropDown;

public class DropDownActivity extends Activity implements OnClickListener{
	private String[]array_1 = {"Gingerbread", "Froyo", "Cupcake", "Donut", "Eclair"};
	private String[]array_2 = {"Milestone", "Galaxy", "Nexus One", "MotoBlur"};
	
	private DropDown dropDown_1, dropDown_2;
	private TextView textView_1, textView_2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		ViewGroup v = (ViewGroup)findViewById(R.id.dropdown_2_view);
		textView_1 = (TextView)findViewById(R.id.dropdown_text_1);
		textView_2 = (TextView)findViewById(R.id.dropdown_text_2);
		
		dropDown_1 = ((DropDown)findViewById(R.id.dropdown));
		dropDown_1.setFocusable(true);
		
		dropDown_2 = new DropDown(this);
		RelativeLayout.LayoutParams ll = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		dropDown_2.setLayoutParams(ll);
		v.addView(dropDown_2);

		dropDown_1.setData(array_1);
		dropDown_2.setData(array_2);
		dropDown_1.setFieldsNumber(4);
		dropDown_2.setFieldsNumber(3);
		((DropDown)findViewById(R.id.dropdown_disabled)).setEnabled(false);
		((DropDown)findViewById(R.id.dropdown_disabled)).setDisplayText("Disabled Dropdown");
		
		//listeners
		dropDown_1.setOnClickListener(this);
		dropDown_2.setOnClickListener(this);
	}

	public void onClick(View v) {
		if(v == dropDown_1){
			textView_1.setText("Selected Android Os: " + dropDown_1.getSelectedText());
		}else if(v == dropDown_2){
			textView_2.setText("Selected Phone: " +dropDown_2.getSelectedText());
		}
	}
}