package com.att.control;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.att.widgets.lib.control.SliderControl;

public class SliderControlActivity extends Activity implements OnClickListener{

	private SliderControl slider_1, slider_2, slider_3;
	private TextView sliderText_1, sliderText_2, sliderText_3;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    
        slider_1 = (SliderControl)findViewById(R.id.slider_bar_1);
        slider_2 = (SliderControl)findViewById(R.id.slider_bar_2);
        slider_2.setStep(50.0f);
        slider_3 = (SliderControl)findViewById(R.id.slider_bar_3);
        
        sliderText_1 = (TextView)findViewById(R.id.slide_bar_1_text);
        sliderText_2 = (TextView)findViewById(R.id.slide_bar_2_text);
        sliderText_3 = (TextView)findViewById(R.id.slide_bar_3_text);
        
        slider_2.setProgressFillColor(true);
        slider_3.setEnabled(false);
        
        slider_1.setOnClickListener(this);
        slider_2.setOnClickListener(this);
        slider_3.setOnClickListener(this);
        
    }

	@Override
	public void onClick(View v) {
		if(v == slider_1){
			sliderText_1.setText("Value: " + slider_1.getCurrent());
		}else if(v == slider_2){
			sliderText_2.setText("Value: " + slider_2.getCurrent());
		}else if(v == slider_3){
			sliderText_3.setText("Value: " + slider_3.getCurrent());
		}
		
	}
}