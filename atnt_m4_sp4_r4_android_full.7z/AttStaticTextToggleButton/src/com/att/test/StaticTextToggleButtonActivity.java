package com.att.test;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;

import com.att.widgets.lib.button.StaticTextToggleButton;

public class StaticTextToggleButtonActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        StaticTextToggleButton toggleButtonDisabled = (StaticTextToggleButton) findViewById(R.id.toggle_disabled);
        toggleButtonDisabled.setEnabled(false);
        
        StaticTextToggleButton toggleButton = new StaticTextToggleButton(this);
        toggleButton.setText("Toggle Button added by code");
        
        ViewGroup view = (ViewGroup) findViewById(R.id.toggle_button_main);
        view.addView(toggleButton);
    }
}